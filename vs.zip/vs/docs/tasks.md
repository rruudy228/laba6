# Псевдокод (бизнес-процессы)

## AddToCart

```text
ALGORITHM AddToCart(userId, productId, qty):
  IF qty <= 0 THEN
     RETURN error "qty must be positive"

  cart ← GetOrCreateActiveCart(userId)
  product ← GetProduct(productId)

  IF product does not exist THEN
     RETURN error "product not found"

  IF product.stock_qty < qty THEN
     RETURN error "not enough stock"

  UpsertCartItem(cart.id, productId, qty, product.price)
  RETURN success
```

## CheckoutFromCart

```text
ALGORITHM CheckoutFromCart(userId):
  cart ← GetActiveCart(userId)

  IF cart is null OR cart.items is empty THEN
     RETURN error "cart is empty"

  BEGIN TRANSACTION
    orderId ← CreateOrder(userId, status="NEW")

    FOR EACH item IN cart.items DO
      product ← GetProduct(item.productId)

      IF product.stock_qty < item.qty THEN
        ROLLBACK
        RETURN error "not enough stock"
      ENDIF

      DecreaseStock(product.id, item.qty)
      AddOrderItem(orderId, product.id, item.qty, item.price_snapshot)
    ENDFOR

    total ← CalculateOrderTotal(orderId)
    UpdateOrderTotal(orderId, total)

    MarkCartAsConverted(cart.id)
  COMMIT

  RETURN orderId
```

## ChangeOrderStatus (админ)

```text
ALGORITHM ChangeOrderStatus(adminUserId, orderId, newStatus):
  IF NOT IsAdmin(adminUserId) THEN
     RETURN error "forbidden"

  order ← GetOrder(orderId)
  IF order does not exist THEN
     RETURN error "not found"

  UpdateOrderStatus(orderId, newStatus)
  RETURN success
```
