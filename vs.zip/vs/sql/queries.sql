-- PhoneShop (SkyPhone) sample queries

-- 1) Products list (page size 20)
-- :offset - integer
SELECT id, title, brand, price, stock_qty
FROM products
ORDER BY created_at DESC
LIMIT 20 OFFSET :offset;

-- 2) Product by id
-- :product_id - bigint
SELECT *
FROM products
WHERE id = :product_id;

-- 3) Get active cart for user
-- :user_id - bigint
SELECT *
FROM carts
WHERE user_id = :user_id AND status = 'ACTIVE'
ORDER BY created_at DESC
LIMIT 1;

-- 4) Upsert cart item (add qty)
-- :cart_id, :product_id, :qty, :price
INSERT INTO cart_items(cart_id, product_id, qty, price_snapshot)
VALUES (:cart_id, :product_id, :qty, :price)
ON CONFLICT (cart_id, product_id)
DO UPDATE SET qty = cart_items.qty + EXCLUDED.qty;

-- 5) Create order header
-- :user_id
INSERT INTO orders(user_id, status)
VALUES (:user_id, 'NEW')
RETURNING id;

-- 6) Move cart_items -> order_items (concept)
-- :order_id, :cart_id
INSERT INTO order_items(order_id, product_id, qty, price_snapshot)
SELECT :order_id, ci.product_id, ci.qty, ci.price_snapshot
FROM cart_items ci
WHERE ci.cart_id = :cart_id;

-- 7) Calculate order total
-- :order_id
UPDATE orders o
SET total_amount = t.sum_amount
FROM (
  SELECT order_id, SUM(qty * price_snapshot) AS sum_amount
  FROM order_items
  WHERE order_id = :order_id
  GROUP BY order_id
) t
WHERE o.id = t.order_id;

-- 8) Mark cart converted and clear items
-- :cart_id
UPDATE carts
SET status = 'CONVERTED'
WHERE id = :cart_id;

DELETE FROM cart_items
WHERE cart_id = :cart_id;
